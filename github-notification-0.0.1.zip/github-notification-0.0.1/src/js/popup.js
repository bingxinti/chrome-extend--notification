(function() {
    $("#status").html("Hello Chrome Extentions");
})();
