# github-notification
一款开源的，关于Github通知和监控个人项目的Chrome扩展应用程序

建设中，开发完会发布到chrome应用中，好期待~！
